l1 = ['shoes','cars','laptop']

for i,j in enumerate(l1):
  print(i,j)